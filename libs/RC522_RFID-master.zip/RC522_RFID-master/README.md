RC522_RFID
==========

RC522_RFID library ported to Spark Core with added support for Software SPI

To use with Spark web IDE:

1. Create new APP, naming it rc522_rfid (.ino automatically added by IDE)
2. Create a new set of tabs with the name "RFID" (which will create RFID.h and RFID.cpp)
3. Copy the code from the same github files into the corresponding tabs (.h and .cpp)
4. Copy the code from github file RC522_RFID.ino into the rc522_rfid.ino tab, writing over anything already in the tab
5. Verify the code
6. Enjoy!

